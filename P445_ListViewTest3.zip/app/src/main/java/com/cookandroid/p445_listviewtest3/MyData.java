package com.cookandroid.p445_listviewtest3;

public class MyData {

    public int icon;
    public String name;

    public MyData(int icon, String name) {
        this.icon = icon;
        this.name = name;
    }
}
