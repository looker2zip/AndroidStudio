package com.cookandroid.p452_gridviewtest;

public class MyData {

    public int icon;
    public String name;

    public MyData(int icon, String name) {
        this.icon = icon;
        this.name = name;
    }
}

