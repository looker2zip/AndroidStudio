k8s@nfs:/var/www/html$ cat mysqltest.php 
<?php

if(!$conn = mysqli_connect('localhost', 'root', 'q1w2e3r4T%')) echo "mysql 연결실패<br/>";

else echo "mysql 연결성공<br/>";

?>

