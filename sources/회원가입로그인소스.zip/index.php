k8s@nfs:/var/www/html$ cat index.php
<?php
	phpinfo();
?>
