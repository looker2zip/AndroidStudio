package org.lklab.dkkim.p658_echoclient;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import java.io.IOException;
import java.io.OutputStream;

class SendThread extends Thread {

    private ClientThread mClientThread;
    private OutputStream mOutStream;
    public static Handler mHandler;

    public SendThread(ClientThread clientThread, OutputStream outStream) {
        mClientThread = clientThread;
        mOutStream = outStream;
    }

    @Override
    public void run() {
        Looper.prepare();
        mHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 1: // 데이터 송신 메시지
                        try {
                            String s = (String) msg.obj;
                            mOutStream.write(s.getBytes());
                            mClientThread.doPrintln("[보낸 데이터] " + s);
                        } catch (IOException e) {
                            mClientThread.doPrintln(e.getMessage());
                        }
                        break;
                    case 2: // 스레드 종료 메시지
                        getLooper().quit();
                        break;
                }
            }
        };
        Looper.loop();
    }
}
