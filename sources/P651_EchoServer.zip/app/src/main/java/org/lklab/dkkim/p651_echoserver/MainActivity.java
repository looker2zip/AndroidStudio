package org.lklab.dkkim.p651_echoserver;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ServerThread mServerThread; // 서버 통신 담당
    private TextView mTextOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextOutput = (TextView) findViewById(R.id.textOutput);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        android.os.Process.killProcess(android.os.Process.myPid());
    }

    public void mOnClick(View v) {
        switch (v.getId()) {
            case R.id.btnStart:
                if (mServerThread == null) {
                    mServerThread = new ServerThread(this, mMainHandler);
                    mServerThread.start();
                }
                break;
            case R.id.btnQuit:
                finish();
                break;
        }
    }

    private Handler mMainHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1: // 화면에 데이터 출력
                    mTextOutput.append((String) msg.obj);
                    break;
            }
        }
    };
}